let num = Math.floor(Math.random()* 20) + 1;

function action(num){
	let display = document.getElementById("results");
	guess(num, display);
	display.classList.remove("hide");
}

function guess(num, display){
	let guess = document.getElementById('guess').value;
	let guessresult = document.createElement("guessresult");
	if(num == guess){
		guessresult.innerHTML = `You got it! Your guess was ${guess}, the number was ${num}`;
	}
	else if (num > guess){
		guessresult.innerHTML = `No, try a higher number. Your guess was ${guess}.<br>`;
	}
	else if (num < guess){
		guessresult.innerHTML = `No, try a lower number. Your guess was ${guess}.<br>`;
	}
	display.appendChild(guessresult);
}

