function message(display, choice){
	let body = display.getElementsByTagName("results")[0];
	let flipresult = document.createElement("flipresult");
	let flip = Math.floor(Math.random() * 2);
	if (flip == 0 && choice == 0){
		flipresult.innerHTML = `<p>You guessed Heads</p><p>The coin landed on Heads</p><p>You guessed correct!</p>`;
	}
	else if (flip == 0 && choice == 1){
		flipresult.innerHTML = `<p>You guessed Tails</p><p>The coin landed on Heads</p><p>You guessed incorrect!</p>`;
	}
	else if (flip == 1 && choice == 1){
		flipresult.innerHTML = `<p>You guessed Tails</p><p>The coin landed on Tails</p><p>You guessed correct!</p>`;
	}
	else if (flip == 1 && choice == 0){
		flipresult.innerHTML = `<p>You guessed Heads</p><p>The coin landed on Tails</p><p>You guessed incorrect!</p>`;
	}
	display.appendChild(flipresult);
}

function action(choice){
	let display = document.getElementById("results");
	message(display, choice);
	display.classList.remove("hide");
}
